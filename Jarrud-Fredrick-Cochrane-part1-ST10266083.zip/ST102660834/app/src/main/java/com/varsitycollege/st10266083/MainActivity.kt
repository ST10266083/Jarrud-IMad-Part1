package com.varsitycollege.st10266083
// All the imports.
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
// Reference:https://stackoverflow.com/questions/12974991/dynamically-added-button-eventlistener
// Reference:https://www.geeksforgeeks.org/kotlin-when-expression/

    class MainActivity : AppCompatActivity() {

        // Creating private variables
        private lateinit var number1EditText: EditText
        private lateinit var number2EditText: EditText
        private lateinit var resultTextView: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Creating User interface with IDS.
        number1EditText = findViewById(R.id.number1EditText)
        number2EditText = findViewById(R.id.number2EditText)
        resultTextView = findViewById(R.id.resultTextView)
        val plusButton = findViewById<Button>(R.id.plusButton)
        val minusButton = findViewById<Button>(R.id.minusButton)
        val timesButton = findViewById<Button>(R.id.timesButton)
        val divideButton = findViewById<Button>(R.id.divideButton)

        // Setting the buttons to the OnClicklisteners
        plusButton.setOnClickListener {

            val num1 = number1EditText.text.toString().toInt()
            val num2 = number2EditText.text.toString().toInt()
            addition(num1, num2)
        }

        minusButton.setOnClickListener {

            val num1 = number1EditText.text.toString().toInt()
            val num2 = number2EditText.text.toString().toInt()
            subtraction(num1, num2)
        }

        timesButton.setOnClickListener {

            val num1 = number1EditText.text.toString().toInt()
            val num2 = number2EditText.text.toString().toInt()
            multiplication(num1, num2)
        }

        divideButton.setOnClickListener {

            val num1 = number1EditText.text.toString().toInt()
            val num2 = number2EditText.text.toString().toInt()
            division(num1, num2)
        }
    }

       // Creating a function to perform all the arithmetic tasks
        private fun addition(num1: Int, num2: Int) {
           val result = num1 + num2

            // Display the result for all the calculations
            resultTextView.text = "$num1 + $num2 = $result"
        }
        private fun subtraction(num1: Int, num2: Int) {
            val result = num1 - num2

            // Display the result for all the calculations
            resultTextView.text = "$num1 - $num2 = $result"
        }
        private fun multiplication(num1: Int, num2: Int) {
            val result = num1 * num2

            // Display the result for all the calculations
            resultTextView.text = "$num1 * $num2 = $result"
        }
        private fun division(num1: Int, num2: Int) {
            val result = num1 / num2

            // Display the result for all the calculations
            resultTextView.text = "$num1 / $num2 = $result"
            
        }

    }
